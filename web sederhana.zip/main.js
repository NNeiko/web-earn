console.log('Hello World!');


//confirm('apakah anda pria sigma?');//


let hewan = 'ikan, gajah, ayam';
console.log(hewan)


var y = 1;
var x = 8;
var z = y + x;
console.log(z)
